package JavaAdvanced.Classes.Exe.CompanyRoster;

import java.util.ArrayList;
import java.util.List;

public class Department {
    private String name;
    private List<Employee> employees;
    private int count;

    public Department(String name){
        this.name = name;
        this.employees = new ArrayList<>();
    }
    public String getName(){
        return this.name;
    }
    public void addEmployee(Employee employee){
        this.employees.add(count++, employee);
    }

    public List<Employee> getEmployees() {
        return employees;
    }
}
