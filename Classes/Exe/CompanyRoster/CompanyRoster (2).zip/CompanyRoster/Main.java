package JavaAdvanced.Classes.Exe.CompanyRoster;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.HashSet;
import java.util.Set;

public class Main {

    public static void main(String[] args) throws IOException {

        BufferedReader reader =
                new BufferedReader(new InputStreamReader(System.in));

        int n = Integer.parseInt(reader.readLine());

        Set<Department> departments = new HashSet<>();
        for (int i = 1; i <= n; i++) {
            String[] data = reader.readLine().split("\\s+");
            String name = data[0];
            double salary = Double.parseDouble(data[1]);
            String position = data[2];
            String department = data[3];

            Employee employee = new Employee(name, salary, position, department);
            if (data.length == 6){
                String email = data[4];
                int age = Integer.parseInt(data[5]);
                employee.setEmail(email);
                employee.setAge(age);
            }else if (data.length == 5){
                if (Character.isDigit(data[4].charAt(0))){
                    int age = Integer.parseInt(data[4]);
                    employee.setAge(age);
                }else{
                    String email = data[4];
                    employee.setEmail(email);
                }
            }
            boolean isFound = false;
            for (Department departmentName : departments) {
                if (departmentName.getName().equals(department)){
                    isFound = true;
                    break;
                }
            }
            if (!isFound){
                Department department1 = new Department(department);
                departments.add(department1);
            }
            for (Department department2 : departments){
                if (department2.getName().equals(department)){
                    department2.addEmployee(employee);
                }
            }
        }
        String currentBest = "";
        double totalBest = 0;
        for (Department department : departments){
            double total = 0;
            int counter = 0;
            for (Employee employee : department.getEmployees()) {
                total += employee.getSalary();
                counter++;
            }
            total /= counter;
            if (totalBest < total){
                totalBest = total;
                currentBest = department.getName();
            }
        }
        System.out.printf("Highest Average Salary: %s%n", currentBest);
        for (Department department : departments) {
            if (department.getName().equals(currentBest)){
                department.getEmployees().stream().sorted((e1, e2) -> (int) (e2.getSalary() - e1.getSalary()))
                        .forEach(e -> {
                            System.out.printf("%s %.2f %s %d%n", e.getName(), e.getSalary(), e.getEmail(), e.getAge());
                        });
            }
        }
    }
}
